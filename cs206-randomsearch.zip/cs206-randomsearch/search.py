import os as os


for i in range (0,4):
    os.system("python3 generate.py")
    os.system("python3 simulate.py")
    i = i + 1
