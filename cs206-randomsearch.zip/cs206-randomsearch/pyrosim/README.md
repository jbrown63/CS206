# ludobots
Simplifying the training of neural network controlled robots in pybullet.

# Getting started

Install pybullet:

pip install pybullet
