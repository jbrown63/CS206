import numpy

amplitude = numpy.pi/4
frequency = 12
offset = numpy.pi

FL_amplitude = numpy.pi/4
FL_frequency = 12
FL_phaseOffset = -numpy.pi

BL_amplitude = numpy.pi/4
BL_frequency = 6
BL_phaseOffset = numpy.pi

Gravity_constant = -9.8

Steps_constant = 1000

s = 2 #number of sensors on robot
m = 2 #number of motors on robot